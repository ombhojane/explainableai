# explainableai/__init__.py
from .core import XAIWrapper

__all__ = ['XAIWrapper']