
def example_function():
    print("This is an example function in the explainable_ai package.")
