def example_function(number):
    print("This is an example function.")
    return number